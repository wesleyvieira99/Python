from utils.helper import formata_float_str_moeda

class Produto:
    contador: int = 1

    def __init__(self: object, nome: str, preco: int) -> None:
        self.__codigo: int = Produto.contador
        self.__nome: str = nome
        self.__preco: int = preco
        Produto.contador += 1

    #Property é como se fossem getters e setter

    @property
    def codigo(self: object) -> int:
        return self.__codigo

    @property
    def nome(self: object) -> str:
        return self.__nome

    @property
    def preco(self: object) -> int:
        return self.__preco

    def __str__(self) -> str:
        return f'Código do produto: {self.codigo} \n Nome: {self.nome} \n Preço: {formata_float_str_moeda(self.preco)}'



