from models.produto import Produto

ps4 = Produto('PlayStation4', 1789.44)
xbox = Produto('Xbox One', 2000.00)

print(ps4, xbox)