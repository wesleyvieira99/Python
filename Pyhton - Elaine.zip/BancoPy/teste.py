from models.cliente import Cliente
from models.conta import Conta

Wesley: Cliente = Cliente('Wesley Vieira', 'wesleysv11@gmail.com', '391-293-758-35', '04/02/1999')
Michael: Cliente = Cliente('Michael Menezes', 'michel.meneses@gmail.com', '555-638-895-35', '18/11/1999')


contaf: Conta = Conta(Wesley)
contaa: Conta = Conta(Michael)

print(contaa)
print(contaf)

