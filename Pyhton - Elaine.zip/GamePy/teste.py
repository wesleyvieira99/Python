from models.calcular import Calcular

calc: Calcular = Calcular (dificuldade=1)

print(calc)